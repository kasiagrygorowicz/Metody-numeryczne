function y = calculate_predicator(x,y,h,f)
    y = y + h*f(x,y);