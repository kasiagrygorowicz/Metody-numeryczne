% Konarski Jan, Grygorowicz Katarzyna
clc;
clear;

x0 = 0;
y0 = 1;
x = 5;
h = [0.05];


% Wynik analityczny
f = @(x,y) (-15*y);



for i = 1:length(h)
    xs =x0:h(i):x;
   
   ref = exp(-15*xs);
    results_e = heun_method( h(i), x0, y0, x,f);
    results_a = adams2( h(i), x0, y0, x,f);
%     results_h = heun_method(h(i), x0, y0, x,f);

% plot(xs, ra);
title("Przebieg rozwiazania rownania rozniczkowego");

plot(xs,ref);
hold on
plot(results_e(1,:), results_e(2,:));
plot(results_a(1,:), results_a(2,:));
 legend('metoda heuna','metod adamsa','rozwiazanie analityczne');
  
    

end